package main

import "fmt"

func main() {
	//var card string = "Ace of Spades"
	card := "Ace of Spades"   // := is used for declaration only
	card = "Five of Diamonds" // = is used for assignment

	fmt.Println(card)
}
