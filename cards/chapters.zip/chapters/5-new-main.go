package main

func main() {
	cards := newDeck()

	cards.print()
}
